
import hashlib
import os
import secrets
import blake3
from concurrent.futures import ThreadPoolExecutor

# Quantum-safe hash function

# Merkle Tree class with lazy rebalancing
def hash_function(data):
    return blake3.blake3(data).digest()
class MerkleTree:
    def __init__(self, secrets, rebalance_threshold=50):
        self.secrets = secrets
        self.salts = [os.urandom(16) for _ in secrets]
        self.leaves = [hash_function(secret + salt) for secret, salt in zip(secrets, self.salts)]
        self.tree = []
        self.proof_cache = {}  # Cache for proofs and intermediate hashes
        self.rebalance_threshold = rebalance_threshold
        self.update_count = 0
        self.build_flat_tree()

    def build_flat_tree(self):
        """Build the Merkle tree using a flat array representation."""
        self.tree = self.leaves[:]
        n = len(self.leaves)
        while n > 1:
            level_start = len(self.tree)
            for i in range(0, n, 2):
                left = self.tree[level_start - n + i]
                right = self.tree[level_start - n + i + 1] if i + 1 < n else left
                self.tree.append(hash_function(left + right))
            n = (n + 1) // 2  # Number of nodes in the next level

    def rebuild_proof_cache(self):
        """Rebuild the proof cache incrementally."""
        self.proof_cache = {i: self._compute_proof(i) for i in range(len(self.leaves))}

    def _compute_proof(self, index):
        """Compute the Merkle proof for a specific index."""
        proof = []
        current_index = index
        n = len(self.leaves)
        for level_start in range(0, len(self.tree) - n + 1, n):
            sibling_index = current_index ^ 1  # XOR to find sibling index
            if sibling_index < n:
                proof.append(self.tree[level_start + sibling_index])
            current_index //= 2
            n = (n + 1) // 2
        return proof

    def get_root(self):
        """Retrieve the root hash of the Merkle tree."""
        return self.tree[-1] if self.tree else None

    def get_proof(self, index):
        """Retrieve the proof for a specific index."""
        return self.proof_cache.get(index, [])

    def add_secret(self, new_secret):
        """Add a new secret and update the proof cache incrementally."""
        salt = os.urandom(16)
        new_leaf = hash_function(new_secret + salt)
        self.secrets.append(new_secret)
        self.salts.append(salt)
        self.leaves.append(new_leaf)
        self.update_count += 1

        # Rebuild the flat tree and proof cache
        self.build_flat_tree()
        self.rebuild_proof_cache()

    def update_proof_cache_for_index(self, index):
        """Update proof cache incrementally for a specific index."""
        self.proof_cache[index] = self._compute_proof(index)

    def partial_rebalance(self, updated_index):
        """Rebalance only the affected part of the tree."""
        current_index = updated_index
        for level_index in range(len(self.tree) - 1):
            sibling_index = current_index ^ 1
            parent_index = current_index // 2
            # Update parent hash if sibling exists
            if sibling_index < len(self.tree[level_index]):
                parent_hash = hash_function(
                    self.tree[level_index][current_index] + self.tree[level_index][sibling_index]
                )
                self.tree[level_index + 1][parent_index] = parent_hash
            current_index = parent_index

    def lazy_rebalance(self):
        """Perform full rebalancing."""
        print("Performing full rebalancing...")
        self.build_tree()
        self.update_count = 0  # Reset update counter

    def verify(self, index, proof):
        """Verify if the given leaf is part of the Merkle tree using the proof."""
        leaf = hash_function(self.secrets[index] + self.salts[index])
        return self._sequential_verify(leaf, proof, index)

    def _sequential_verify(self, leaf, proof, index):
        """Sequential proof verification."""
        current_hash = leaf
        for sibling in proof:
            if index % 2 == 0:  # Left child
                current_hash = hash_function(current_hash + sibling)
            else:  # Right child
                current_hash = hash_function(sibling + current_hash)
            index //= 2
        return current_hash == self.get_root()